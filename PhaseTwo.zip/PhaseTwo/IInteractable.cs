﻿namespace PhaseTwo
{
	interface IInteractable
	{
        // Used when the player interacts with an NPC (Merchant)
        void Interact(Player player) { }
	}
}
